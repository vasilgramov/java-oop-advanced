package p05_kingGambit.models.interfaces;

/**
 * Created by vladix on 4/12/17.
 */
public interface Attackable {

    void attack();

}
