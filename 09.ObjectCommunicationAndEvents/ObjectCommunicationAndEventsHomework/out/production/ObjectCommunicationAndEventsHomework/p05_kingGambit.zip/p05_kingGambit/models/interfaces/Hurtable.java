package p05_kingGambit.models.interfaces;

/**
 * Created by vladix on 4/19/17.
 */
public interface Hurtable {

    void hurt();

}
