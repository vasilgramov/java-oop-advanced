package p05_kingGambit.core;

/**
 * Created by vladix on 4/12/17.
 */
public interface CommandHandler {

    void execute();

}
