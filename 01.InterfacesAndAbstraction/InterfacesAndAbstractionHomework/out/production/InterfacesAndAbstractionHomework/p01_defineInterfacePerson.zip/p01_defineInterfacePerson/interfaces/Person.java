package p01_defineInterfacePerson.interfaces;

public interface Person {
    String getName();
    int getAge();
}
