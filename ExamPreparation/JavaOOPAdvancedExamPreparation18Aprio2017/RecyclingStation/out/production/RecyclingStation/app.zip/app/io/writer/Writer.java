package app.io.writer;

/**
 * Created by vladix on 4/19/17.
 */
public interface Writer {

    void writeLine(String line);

}
