package app.io.reader;

import java.io.IOException;

/**
 * Created by vladix on 4/19/17.
 */
public interface Reader {

    String readLine() throws IOException;

}
