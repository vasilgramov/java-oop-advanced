package app.enums;

/**
 * Created by vladix on 4/19/17.
 */
public enum GargabeType {

    RECYCLABLE,
    BURNABLE,
    STORABLE;

}
